<?php header('Location: public/');

?>
